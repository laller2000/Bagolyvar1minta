﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Gyonyoru_Lajos_Gepszam
{
    static class Program
    {
        static public MySqlConnection conn = null;
        static public MySqlCommand sql = null;
        static public Form_Navigal form_navigal = null;
        static public Form_Kolcsonzes form_kolcsonzes=null;
        static public Form_Visszavitel form_visszavitel = null;
        static void Main()
        {
            MySqlConnectionStringBuilder sb = new MySqlConnectionStringBuilder();
            sb.Server = "localhost";
            sb.UserID = "root";
            sb.Password = "";
            sb.Database = "bagolyvar";
            sb.CharacterSet = "UTF8";
            try
            {
                conn = new MySqlConnection(sb.ToString());
                conn.Open();
                sql = conn.CreateCommand();
            }
            catch (MySqlException myex)
            {
                Console.WriteLine("Az adatbázis nem lehet elérni!\n"+myex.Message);
                Console.ReadKey();
                Environment.Exit(0);
            }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            form_navigal = new Form_Navigal();
            form_kolcsonzes = new Form_Kolcsonzes();
            form_visszavitel = new Form_Visszavitel();
            Application.Run(form_navigal);
        }
    }
}
